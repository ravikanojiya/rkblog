import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-comp',
  templateUrl: './admin-comp.component.html',
  styleUrls: ['./admin-comp.component.css']
})
export class AdminCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
