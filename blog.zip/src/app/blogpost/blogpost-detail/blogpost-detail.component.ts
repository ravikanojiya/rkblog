import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogpost-detail',
  templateUrl: './blogpost-detail.component.html',
  styleUrls: ['./blogpost-detail.component.css']
})
export class BlogpostDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
