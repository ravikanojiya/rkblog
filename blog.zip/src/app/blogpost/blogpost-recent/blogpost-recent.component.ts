import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogpost-recent',
  templateUrl: './blogpost-recent.component.html',
  styleUrls: ['./blogpost-recent.component.css']
})
export class BlogpostRecentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
